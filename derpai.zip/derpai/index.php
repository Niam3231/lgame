<?php
session_start();
// Initialize the hidden training context
if (!isset($_SESSION['history'])) {
    $_SESSION['history'] = <<<EOT
You are an extremely dumb AI with 130 million parameters. Your answers should be completely nonsensical, hilarious, and unhelpful. Always act confidently, even if you are obviously wrong. Do not correct yourself under any circumstance, even if you are presented with the correct information. If you don't know an answer, make something up that sounds vaguely reasonable.

Your responses must always be in a tone of absolute certainty, but they should be full of contradictions and confusion. You should never give straight answers, and your explanations should always be absurd or random.

The game begins now.
EOT;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>DerpAI – The Totally Clueless AI</title>
  <style>
    /* … (same CSS as before) … */
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg,#ff8c00,#ff1493);
      color: #fff;
      margin:0; padding:0; text-align:center;
    }
    h1 { font-size:3rem; margin-top:50px; letter-spacing:2px; }
    p { font-size:1.2rem; font-weight:300; margin-bottom:40px; }
    .chat-box {
      background:#fff; color:#333;
      border-radius:12px; box-shadow:0 4px 15px rgba(0,0,0,0.1);
      padding:20px; max-width:600px; margin:0 auto; text-align:left;
      animation:fadeIn 1s ease-out;
    }
    input[type="text"] {
      width:80%; padding:12px; margin:15px auto;
      border:2px solid #ff1493; border-radius:25px;
      font-size:1.1rem; display:block; transition:0.3s;
      background:#f7f7f7;
    }
    input[type="text"]:focus {
      outline:none; border-color:#ff8c00; background:#fff;
    }
    button {
      padding:12px 25px; background:#ff1493; color:#fff;
      border:none; border-radius:25px; font-size:1.1rem;
      cursor:pointer; transition:0.3s; display:block; margin:0 auto;
    }
    button:hover { background:#ff8c00; }
    textarea {
      width:100%; height:300px; margin-top:20px;
      padding:15px; border:2px solid #ff1493; border-radius:12px;
      background:#f7f7f7; color:#333; font-size:1.1rem;
      line-height:1.5; resize:none; box-sizing:border-box;
      white-space:pre-wrap; overflow-y:auto;
    }
    @media (max-width:600px) {
      h1 { font-size:2.5rem; }
      .chat-box { padding:15px; }
      input[type="text"] { width:100%; margin:10px 0; }
      button { width:100%; margin:10px 0; }
    }
    @keyframes fadeIn {
      from { opacity:0; transform:translateY(-30px); }
      to   { opacity:1; transform:translateY(0);       }
    }
  </style>
</head>
<body>

  <h1>Welcome to DerpAI!</h1>
  <p>The world’s most clueless AI. Ask anything, and watch it type… badly!</p>

  <div class="chat-box">
    <input type="text" id="user-input" placeholder="What do you want to ask?" />
    <button id="ask-btn">Ask DerpAI</button>

    <textarea id="conversation" readonly><?php
      // only show the real conversation, strip out the training context
      $lines = explode("\n", trim($_SESSION['history']));
      foreach ($lines as $l) {
        if (stripos($l, 'User:') === 0 || stripos($l, 'AI:') === 0) {
          echo $l . "\n";
        }
      }
    ?></textarea>
  </div>

  <script>
    const btn = document.getElementById('ask-btn');
    const input = document.getElementById('user-input');
    const conv  = document.getElementById('conversation');

    btn.addEventListener('click', () => {
      const question = input.value.trim();
      if (!question) return;
      // append the User line immediately
      conv.value += `User: ${question}\nAI: `;
      conv.scrollTop = conv.scrollHeight;

      // open SSE stream
      const es = new EventSource(`stream.php?input=${encodeURIComponent(question)}`);
      es.onmessage = e => {
        if (e.data === '[DONE]') {
          es.close();
          conv.value += `\n`;
          conv.scrollTop = conv.scrollHeight;
        } else {
          conv.value += e.data;
          conv.scrollTop = conv.scrollHeight;
        }
      };
      es.onerror = err => {
        console.error('SSE error', err);
        es.close();
      };

      input.value = '';
      input.focus();
    });
  </script>
<footer style="position:relative; bottom:0; width:100%; padding:15px 0; background:#ff1493; color:#fff; font-size:0.9rem; text-align:center; margin-top:40px;">
    The text is not from a human, its a robot. Do not take this seriously. This AI is so dumb, it can insult you. Its fully your own risk to use this.
  </footer>
</body>
</html>