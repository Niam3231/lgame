<?php
require 'vendor/autoload.php';
use ArdaGnsrn\Ollama\Ollama;

session_start();
// append the new user input to the hidden history
if (!isset($_GET['input'])) {
    http_response_code(400);
    exit;
}
$user = trim($_GET['input']);
$_SESSION['history'] .= "\nUser: {$user}\nAI:";

// set headers for Server-Sent Events
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');

// tell PHP to flush after every output
while (ob_get_level() > 0) ob_end_flush();
ob_implicit_flush(true);

// stream from Ollama
$client = Ollama::client('http://localhost:11434');
$responses = $client->completions()->createStreamed([
    'model'  => 'smollm2:135m',
    'prompt' => $_SESSION['history'],
]);

$full = '';
foreach ($responses as $chunk) {
    $text = $chunk->response;
    $full .= $text;
    // send as SSE data
    echo "data: " . str_replace("\n", "", $text) . "\n\n";
    // flush immediately
    flush();
    usleep(200000); // optional pacing
}

// finalize
$_SESSION['history'] .= " {$full}\n";
echo "data: [DONE]\n\n";
flush();